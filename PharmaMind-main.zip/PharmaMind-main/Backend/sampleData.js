const drugData={
  "drug_name": "Metformin",
  "summary": {
    "overall_insight": "Metformin shows promising repurposing potential for cancer and neurological disorders. Recent trials and patents highlight ongoing innovation in oncology applications."
  },
  
  "clinical_trials": {
    "total_trials": 17,
    "trials_by_disease": {
      "Cancer": 12,
      "PCOS": 3,
      "Obesity": 2
    },
    "key_trials": [
      {
        "title": "Metformin as Adjuvant Therapy in Breast Cancer",
        "phase": "Phase II",
        "status": "Active",
        "year": 2023,
        "url": "https://clinicaltrials.gov/study/NCTXXXXXXX"
      },
      {
        "title": "Metformin in Obesity Management",
        "phase": "Phase III",
        "status": "Completed",
        "year": 2022,
        "url": "https://clinicaltrials.gov/study/NCTYYYYYYY"
      }
    ],
    "summary": "Most trials explore cancer-related repurposing, especially in breast and colon cancer."
  },

  "research_papers": {
    "total_papers": 25,
    "key_topics": ["Anti-cancer", "Neuroprotection", "Inflammation control"],
    "top_papers": [
      {
        "title": "Metformin’s Anti-tumor Mechanisms: A Comprehensive Review",
        "year": 2023,
        "authors": ["J. Lee", "A. Sharma"],
        "url": "https://www.semanticscholar.org/paper/XXXXX"
      },
      {
        "title": "Neuroprotective Potential of Metformin in Alzheimer’s Models",
        "year": 2024,
        "authors": ["S. Wang", "M. Gupta"],
        "url": "https://pubmed.ncbi.nlm.nih.gov/XXXXXX"
      }
    ],
    "summary": "Emerging literature highlights its anti-cancer and neuroprotective roles."
  },

  "patents": {
    "total_patents": 5,
    "recent_patents": [
      {
        "title": "Novel Metformin Formulation for Oncology Applications",
        "year": 2023,
        "applicant": "Pfizer Inc.",
        "url": "https://www.lens.org/patent/XXXXXX"
      },
      {
        "title": "Metformin-based Combination Therapy for Alzheimer’s",
        "year": 2022,
        "applicant": "AstraZeneca",
        "url": "https://www.lens.org/patent/YYYYYY"
      }
    ],
    "patent_trend": {
      "2021": 1,
      "2022": 3,
      "2023": 5
    },
    "summary": "Increasing patent activity since 2021, mostly around oncology formulations."
  },

  "market_analysis": {
    "top_indications": [
      {
        "disease": "Cancer",
        "market_size_usd_billion": 200,
        "competition": "Moderate",
        "potential_score": 0.82
      },
      {
        "disease": "PCOS",
        "market_size_usd_billion": 5,
        "competition": "High",
        "potential_score": 0.45
      }
    ],
    "summary": "Highest commercial potential found in oncology markets ($200B, moderate competition)."
  },

  "visualization_data": {
    "charts": {
      "trials_by_disease": {
        "Cancer": 12,
        "PCOS": 3,
        "Obesity": 2
      },
      "patent_trend": {
        "2021": 1,
        "2022": 3,
        "2023": 5
      },
      "market_potential": {
        "Cancer": 200,
        "PCOS": 5
      }
    }
  },

  "report_links": {
    "pdf_report": "https://pharmamind.ai/reports/metformin_report.pdf",
    "timestamp": "2025-10-27T19:55:00Z"
  }
}

export default drugData;