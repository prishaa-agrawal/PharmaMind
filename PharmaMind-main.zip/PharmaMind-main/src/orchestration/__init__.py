"""Orchestration package for PharmaMind."""
from .master_agent import get_master_chain

__all__ = ['get_master_chain']

