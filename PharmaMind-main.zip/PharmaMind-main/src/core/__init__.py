"""Core package for PharmaMind."""
from .llm_provider import llm

__all__ = ['llm']

