"""PharmaMind package."""

